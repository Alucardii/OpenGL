package org.example;

import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.system.MemoryUtil.NULL;

class Window {
    private final int width;
    private final int height;
    private final String title;
    private long window;

    public Window(int width, int height, String title) {
        this.width = width;
        this.height = height;
        this.title = title;
    }

    public void init() {
        if (!glfwInit()) {
            throw new IllegalStateException("Не удалось инициализировать GLFW");
        }

        window = glfwCreateWindow(width, height, title, NULL, NULL);
        if (window == NULL) {
            throw new RuntimeException("Не удалось создать окно GLFW");
        }

        glfwMakeContextCurrent(window);
        glfwSwapInterval(1); // Включение VSync
        glfwShowWindow(window);
        GL.createCapabilities();
    }

    public boolean shouldClose() {
        return glfwWindowShouldClose(window);
    }

    public void swapBuffers() {
        glfwSwapBuffers(window);
    }

    public void pollEvents() {
        glfwPollEvents();
    }

    public long getHandle() {
        return window;
    }

    public void terminate() {
        glfwTerminate();
    }
}

class ShapeDrawer {
    private int drawMode = GL11.GL_FILL;

    public void setDrawMode(int mode) {
        this.drawMode = mode;
    }

    void drawConnectedShapes(float startX, float startY, float a) {
        GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, drawMode);

        if (drawMode == GL11.GL_POINT) {
            GL11.glPointSize(10.0f);  // Устанавливаем размер точек
        }

        // Рисуем центральный квадрат
        GL11.glBegin(GL11.GL_POLYGON);
        GL11.glColor3f(1.0f, 0.0f, 0.0f); // Красный
        GL11.glVertex2f(startX, startY);
        GL11.glVertex2f(startX + a, startY);
        GL11.glVertex2f(startX + a, startY + a);
        GL11.glVertex2f(startX, startY + a);
        GL11.glEnd();

        // Левый зелёный треугольник
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        GL11.glColor3f(0.0f, 1.0f, 0.0f);
        GL11.glVertex2f(startX - a, startY + a / 2);
        GL11.glVertex2f(startX, startY + a);
        GL11.glVertex2f(startX, startY);
        GL11.glEnd();

        // Центральный желтый треугольник
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        GL11.glColor3f(0.0f, 1.0f, 0.0f);
        GL11.glVertex2f(startX + a, startY);
        GL11.glVertex2f(startX + a + a, startY - a / 2);
        GL11.glVertex2f(startX + 2 * a, startY + a / 2);
        GL11.glEnd();

        // Желтый треугольник (справа)
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        GL11.glColor3f(1.0f, 1.0f, 0.0f);
        GL11.glVertex2f(startX + 2 * a, startY + a / 2);
        GL11.glVertex2f(startX + a, startY + a);
        GL11.glVertex2f(startX + a, startY);
        GL11.glEnd();

        // Синий квадрат
        GL11.glBegin(GL11.GL_POLYGON);
        GL11.glColor3f(0.0f, 0.0f, 1.0f);
        GL11.glVertex2f(startX, startY - a);
        GL11.glVertex2f(startX + a, startY - a);
        GL11.glVertex2f(startX + a, startY);
        GL11.glVertex2f(startX, startY);
        GL11.glEnd();

        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        GL11.glColor3f(1.0f, 0.0f, 0.0f);
        GL11.glVertex2f(startX + a, startY);
        GL11.glVertex2f(startX + a + a, startY - a / 2);
        GL11.glVertex2f(startX + a, startY - a);
        GL11.glEnd();
    }
}

public class MainClass {
    private static final float A = 75.0f;
    private static final float SCALE = 1.0f / 600.0f;

    private final Window window;
    private final ShapeDrawer shapeDrawer;

    public MainClass() {
        this.window = new Window(800, 600, "Connected Shapes");
        this.shapeDrawer = new ShapeDrawer();
    }

    public void run() {
        window.init();
        setupGUI();
        loop();
        window.terminate();
    }

    private void setupGUI() {
        // Создание кнопок
        JFrame frame = new JFrame("Control Panel");
        frame.setLayout(new FlowLayout());
        frame.setSize(200, 100);

        JButton buttonPoint = new JButton("Points");
        buttonPoint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                shapeDrawer.setDrawMode(GL11.GL_POINT);
            }
        });

        JButton buttonLine = new JButton("Lines");
        buttonLine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                shapeDrawer.setDrawMode(GL11.GL_LINE);
            }
        });

        JButton buttonFill = new JButton("Fill");
        buttonFill.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                shapeDrawer.setDrawMode(GL11.GL_FILL);
            }
        });

        frame.add(buttonPoint);
        frame.add(buttonLine);
        frame.add(buttonFill);
        frame.setVisible(true);
    }

    private void loop() {
        while (!window.shouldClose()) {
            GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
            GL11.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

            handleInput();

            int[] windowWidth = new int[1];
            int[] windowHeight = new int[1];
            glfwGetWindowSize(window.getHandle(), windowWidth, windowHeight);

            int width = windowWidth[0];
            int height = windowHeight[0];
            GL11.glViewport(0, 0, width, height);
            GL11.glMatrixMode(GL11.GL_PROJECTION);
            GL11.glLoadIdentity();
            float aspectRatio = (float) width / height;
            if (width >= height) {
                GL11.glOrtho(-aspectRatio, aspectRatio, -1, 1, -1, 1);
            } else {
                GL11.glOrtho(-1, 1, -1 / aspectRatio, 1 / aspectRatio, -1, 1);
            }
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
            GL11.glLoadIdentity();

            shapeDrawer.drawConnectedShapes(0.0f, 0.0f, A * SCALE);

            window.swapBuffers();
            window.pollEvents();
        }
    }

    private void handleInput() {
        if (glfwGetKey(window.getHandle(), GLFW_KEY_1) == GLFW_PRESS) {
            shapeDrawer.setDrawMode(GL11.GL_POINT);
        }
        if (glfwGetKey(window.getHandle(), GLFW_KEY_2) == GLFW_PRESS) {
            shapeDrawer.setDrawMode(GL11.GL_LINE);
        }
        if (glfwGetKey(window.getHandle(), GLFW_KEY_3) == GLFW_PRESS) {
            shapeDrawer.setDrawMode(GL11.GL_FILL);
        }
    }

    public static void main(String[] args) {
        new MainClass().run();
    }
}
