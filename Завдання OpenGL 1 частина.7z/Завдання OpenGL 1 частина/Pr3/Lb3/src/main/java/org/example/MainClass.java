package org.example;

import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;
import org.lwjgl.system.*;

import static org.lwjgl.glfw.Callbacks.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryUtil.*;

public class MainClass {

    private long window;
    private float Xmin = -10, Xmax = 10;
    private float Ymin, Ymax;

    public void run() {
        init();
        calculateYMinMax();
        loop();
        glfwFreeCallbacks(window);
        glfwDestroyWindow(window);
        glfwTerminate();
    }

    private void init() {
        if (!glfwInit()) {
            throw new IllegalStateException("Неможливо ініціалізувати GLFW");
        }

        glfwDefaultWindowHints();
        glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);

        window = glfwCreateWindow(800, 600, "Graph of f1(x) and f2(x)", NULL, NULL);
        if (window == NULL) {
            throw new RuntimeException("Не вдалося створити вікно");
        }

        glfwMakeContextCurrent(window);
        glfwSwapInterval(1);
        glfwShowWindow(window);

        // Додаємо обробник подій для зміни розміру вікна
        glfwSetFramebufferSizeCallback(window, (window, width, height) -> {
            glViewport(0, 0, width, height);
            glOrtho(Xmin, Xmax, Ymin, Ymax, -1, 1); // Оновлюємо проекцію
        });

        GL.createCapabilities();
    }

    private void calculateYMinMax() {
        int N = 220;  // Кількість точок для побудови графіка
        float step = (Xmax - Xmin) / (float) N;

        // Ініціалізація Ymin і Ymax на основі першої точки
        Ymin = f1(Xmin);
        Ymax = f1(Xmin);

        // Перевірка всіх точок
        for (int i = 1; i <= N; i++) {
            float x = Xmin + i * step;
            float y = f1(x);

            // Оновлення Ymin і Ymax
            if (y < Ymin) Ymin = y;
            if (y > Ymax) Ymax = y;
        }

        // Розширення діапазону для зручності відображення графіка
        float buffer = (Ymax - Ymin) * 0.1f;
        Ymin -= buffer;
        Ymax += buffer;
    }

    private void loop() {
        glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Білий фон
        glLineWidth(2.0f); // Товщина ліній

        while (!glfwWindowShouldClose(window)) {
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Очищаємо екран

            // Встановлюємо анізотропну систему координат
            glLoadIdentity();
            glOrtho(Xmin, Xmax, Ymin, Ymax, -1, 1); // Орто-проекція

            // Малюємо координатні осі
            drawAxes();

            // Малюємо графіки функцій f1(x) і f2(x)
            drawGraph(this::f1);  // Графік f1(x)
            drawGraph(this::f2);  // Графік f2(x)

            // Малюємо точки на графіку
            drawPoints(this::f1);  // Точки для f1(x)
            drawPoints(this::f2);  // Точки для f2(x)

            // Обмін буферами
            glfwSwapBuffers(window);

            // Обробка подій
            glfwPollEvents();
        }
    }

    // Малюємо координатні осі
    private void drawAxes() {
        glColor3f(0.0f, 0.0f, 0.0f); // Чорний колір для осей
        drawLine(Xmin, 0, Xmax, 0);  // Ось X
        drawLine(0, Ymin, 0, Ymax);  // Ось Y
    }

    // Малюємо графік функції, переданої як параметр
    private void drawGraph(java.util.function.Function<Float, Float> func) {
        glColor3f(1.0f, 0.0f, 0.0f); // Червоний колір для графіка функції

        int N = 500; // Кількість точок для побудови графіка
        float step = (Xmax - Xmin) / (float) N;

        for (int i = 0; i < N - 1; i++) {
            float x1 = Xmin + i * step;
            float y1 = func.apply(x1);  // Викликаємо передану функцію
            float x2 = Xmin + (i + 1) * step;
            float y2 = func.apply(x2);  // Викликаємо передану функцію
            drawLine(x1, y1, x2, y2); // Малюємо лінію між двома точками
        }
    }

    // Малюємо точки для функції
    private void drawPoints(java.util.function.Function<Float, Float> func) {
        glColor3f(0.0f, 0.0f, 1.0f); // Синій колір для точок

        int N = 500; // Кількість точок для побудови графіка
        float step = (Xmax - Xmin) / (float) N;

        for (int i = 0; i < N; i++) {
            float x = Xmin + i * step;
            float y = func.apply(x); // Викликаємо передану функцію
            drawPoint(x, y); // Малюємо точку
        }
    }

    // Функція для малювання точки
    private void drawPoint(float x, float y) {
        glBegin(GL_POINTS);
        glVertex2f(x, y);
        glEnd();
    }

    // Функція f1(x) = arctg(cos^13(x + 2))
    private float f1(float x) {
        return (float) Math.atan(Math.pow(Math.cos(x + 2), 13));
    }

    // Функція f2(x)
    private float f2(float x) {
        // Ось тут можна змінити на будь-яку іншу функцію
        return (float) Math.sin(x);
    }

    // Метод для малювання лінії
    private void drawLine(float x1, float y1, float x2, float y2) {
        glBegin(GL_LINES);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
        glEnd();
    }

    public static void main(String[] args) {
        new MainClass().run();
    }
}
