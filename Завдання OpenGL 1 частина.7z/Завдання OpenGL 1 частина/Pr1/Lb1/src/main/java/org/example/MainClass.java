package org.example;

import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;
import org.lwjgl.system.*;

import static org.lwjgl.glfw.Callbacks.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryUtil.*;

public class MainClass {

    private long window;

    public void run() {
        init();
        loop();

        // Очищення при виході з програми
        glfwFreeCallbacks(window);
        glfwDestroyWindow(window);
        glfwTerminate();
    }

    private void init() {
        // Ініціалізація GLFW
        if (!glfwInit()) {
            throw new IllegalStateException("Неможливо ініціалізувати GLFW");
        }

        glfwDefaultWindowHints();
        glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);

        window = glfwCreateWindow(800, 600, "OpenGL Project", NULL, NULL);
        if (window == NULL) {
            throw new RuntimeException("Не вдалося створити вікно");
        }

        glfwMakeContextCurrent(window);
        glfwSwapInterval(1);
        glfwShowWindow(window);

        // Додаємо обробник подій для зміни розміру вікна
        glfwSetFramebufferSizeCallback(window, (window, width, height) -> {
            glViewport(0, 0, width, height); // Встановлюємо новий розмір вікна
            glOrtho(-width / 2, width / 2, -height / 2, height / 2, -1, 1); // Перераховуємо проекцію
        });

        GL.createCapabilities();
    }

    Octagon octagon1 = new Octagon(-100, 95, 75, 0.9f, 1.3f, -22.0f, 1.0f, 0.0f, 0.0f, true);
    Octagon octagon2 = new Octagon(120, 95, 75, 0.9f, 1.3f, -22.0f, 0.0f, 0.0f, 1.0f, false);

    private void loop() {
        glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Білий фон
        glLineWidth(2.0f); // Встановлюємо товщину ліній

        // Основний цикл
        while (!glfwWindowShouldClose(window)) {
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Очищаємо екран

            // Встановлення анізотропної системи координат
            glLoadIdentity();
            glOrtho(-400, 400, -300, 300, -1, 1); // Орто-проекція

            // Малювання координатної сітки (пунктирні лінії)
            drawGrid();

            drawAxes();

            octagon1.draw();
            octagon2.draw();

            // Обмін буферами
            glfwSwapBuffers(window);

            // Обробка подій
            glfwPollEvents();
        }
    }

    private void drawAxes() {
        glColor3f(0.0f, 0.0f, 0.0f); // Чорний колір для осей

        // Ось X
        drawLine(-400, 0, 400, 0);

        // Ось Y
        drawLine(0, -300, 0, 300);

        // Стрілка для осі X
        drawArrow(400, 0, 380, 20);
        drawArrow(400, 0, 380, -20);

        // Стрілка для осі Y
        drawArrow(0, 300, 20, 280);
        drawArrow(0, 300, -20, 280);
    }

    private void drawGrid() {
        glEnable(GL_LINE_STIPPLE);
        glLineStipple(1, (short) 0xAAAA);
        glColor3f(0.8f, 0.8f, 0.8f); // Світло-сірий колір для сітки

        // Малювання горизонтальних ліній
        for (int i = -300; i <= 300; i += 30) {
            drawLine(-400, i, 400, i);
        }

        // Малювання вертикальних ліній
        for (int i = -400; i <= 400; i += 30) {
            drawLine(i, -300, i, 300);
        }
    }

    // Метод для малювання ліній
    private void drawLine(float x1, float y1, float x2, float y2) {
        glBegin(GL_LINES);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
        glEnd();
    }

    // Метод для малювання стрілок
    private void drawArrow(float x1, float y1, float x2, float y2) {
        glBegin(GL_LINES);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
        glEnd();
    }

    // Клас для восьмиугольника


    public static void main(String[] args) {
        new MainClass().run();
    }
}
