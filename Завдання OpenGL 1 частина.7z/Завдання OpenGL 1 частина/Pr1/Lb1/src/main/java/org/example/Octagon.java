package org.example;
import org.lwjgl.*;
import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;
import org.lwjgl.system.*;

import java.nio.*;

import static org.lwjgl.glfw.Callbacks.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryUtil.*;

// Класс для восьмиугольника
 class Octagon {
    private float centerX, centerY, radius;
    private float scaleX, scaleY;
    private float rotationAngle;
    private float red, green, blue;
    private boolean drawLines; // Флаг для рисования линий

    // Конструктор для задания всех параметров
    public Octagon(float centerX, float centerY, float radius,
                   float scaleX, float scaleY, float rotationAngle,
                   float red, float green, float blue, boolean drawLines) {
        this.centerX = centerX;
        this.centerY = centerY;
        this.radius = radius;
        this.scaleX = scaleX;
        this.scaleY = scaleY;
        this.rotationAngle = rotationAngle;
        this.red = red;
        this.green = green;
        this.blue = blue;
        this.drawLines = drawLines;
    }

    // Метод для рисования восьмиугольника
    public void draw() {
        // Устанавливаем цвет
        glColor3f(red, green, blue);

        // Вычисление вершин восьмиугольника
        float[] x = new float[8];
        float[] y = new float[8];
        double angleOffset = Math.toRadians(rotationAngle); // Угол поворота

        for (int i = 0; i < 8; i++) {
            double angle = Math.toRadians(45 * i) + angleOffset; // Угол с учетом поворота
            x[i] = centerX + (float) (radius * Math.cos(angle)) * scaleX; // Растяжение по X
            y[i] = centerY + (float) (radius * Math.sin(angle)) * scaleY; // Растяжение по Y
        }

        // Рисование линий между точками (если флаг установлен)
        if (drawLines) {
            glBegin(GL_LINE_LOOP);
            for (int i = 0; i < 8; i++) {
                glVertex2f(x[i], y[i]);
            }
            glEnd();
        }

        // Рисование точек вершин
        glPointSize(5.0f); // Размер точек
        glBegin(GL_POINTS);
        for (int i = 0; i < 8; i++) {
            glVertex2f(x[i], y[i]);
        }
        glEnd();
    }
}
