package org.example;
import org.lwjgl.*;
import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;
import org.lwjgl.system.*;

import java.nio.*;
import static org.lwjgl.glfw.Callbacks.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

public class MainClass {

    private long window;

    // ініціалізація OpenGL та вікна
    public void init() {
        if (!glfwInit()) {
            throw new IllegalStateException("Unable to initialize GLFW");
        }

        glfwDefaultWindowHints();
        window = glfwCreateWindow(800, 600, "OpenGL Example", 0, 0);
        if (window == 0) {
            throw new RuntimeException("Failed to create the GLFW window");
        }

        glfwMakeContextCurrent(window);
        glfwSwapInterval(1);
        glfwShowWindow(window);
        GL.createCapabilities();
    }

    // Малювання еліпса
    public void drawEllipse(float a, float b) {
        glBegin(GL_LINE_LOOP);
        for (int i = 0; i < 360; i++) {
            float angle = (float) Math.toRadians(i);
            float x = a * (float) Math.cos(angle);
            float y = b * (float) Math.sin(angle);
            glVertex2f(x, y);
        }
        glEnd();
    }

    // Малювання окружності
    public void drawCircle(float radius) {
        drawEllipse(radius, radius);
    }

    // Малювання відрізків
    public void drawLine(float x1, float y1, float x2, float y2) {
        glBegin(GL_LINES);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
        glEnd();
    }

    // Рендеринг сцени
    public void render() {
        glClear(GL_COLOR_BUFFER_BIT);
        glLoadIdentity();

        // Малюємо еліпс та відрізки
        glTranslatef(0.0f, 0.0f, 0.0f); // Центр
        glColor3f(1.0f, 0.0f, 0.0f); // Червоний колір
        drawEllipse(0.5f, 0.25f); // Еліпс

        glColor3f(0.0f, 1.0f, 0.0f); // Зелений колір
        drawCircle(0.3f); // Окружність

        glColor3f(0.0f, 0.0f, 1.0f); // Синій колір
        drawLine(-0.5f, -0.2f, 0.5f, 0.2f); // Відрізок 1
        drawLine(-0.3f, 0.4f, 0.3f, -0.4f); // Відрізок 2
    }

    // Основний цикл
    public void loop() {
        while (!glfwWindowShouldClose(window)) {
            render();
            glfwSwapBuffers(window);
            glfwPollEvents();
        }
    }

    // Основна функція
    public static void main(String[] args) {
        MainClass example = new MainClass();
        example.init();
        example.loop();
        glfwDestroyWindow(example.window);
        glfwTerminate();
    }
}
