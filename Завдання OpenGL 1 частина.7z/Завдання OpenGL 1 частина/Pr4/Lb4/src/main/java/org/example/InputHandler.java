package org.example;

import static org.lwjgl.glfw.GLFW.*;
import org.lwjgl.opengl.GL11;

public class InputHandler {
    public int handleInput(long window) {
        if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS) {
            return GL11.GL_POINT;
        }
        if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS) {
            return GL11.GL_LINE;
        }
        if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS) {
            return GL11.GL_FILL;
        }
        return -1; // Не изменять режим, если ничего не нажато
    }
}
