package org.example;

import org.lwjgl.opengl.GL11;

public class ShapeRenderer {
    private int drawMode = GL11.GL_FILL;

    public void setDrawMode(int mode) {
        this.drawMode = mode;
    }

    public void render(float startX, float startY, float a) {
        GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, drawMode);

        if (drawMode == GL11.GL_POINT) {
            GL11.glPointSize(10.0f);
        }

        // Рисуем центральный квадрат (GL_POLYGON)
        GL11.glBegin(GL11.GL_POLYGON);
        GL11.glColor3f(1.0f, 0.0f, 0.0f); // Красный
        GL11.glVertex2f(startX, startY);            // Левый нижний
        GL11.glVertex2f(startX + a, startY);        // Правый нижний
        GL11.glVertex2f(startX + a, startY + a);    // Правый верхний
        GL11.glVertex2f(startX, startY + a);        // Левый верхний
        GL11.glEnd();

        // Левый зелёный треугольник
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        GL11.glColor3f(0.0f, 1.0f, 0.0f); // Зеленый
        GL11.glVertex2f(startX - a, startY + a / 2);  // Центральная точка
        GL11.glVertex2f(startX, startY + a);        // Верхний угол квадрата
        GL11.glVertex2f(startX, startY);            // Нижний угол квадрата
        GL11.glEnd();

        // Центральный желтый треугольник между левым и правым треугольниками
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        GL11.glColor3f(0.0f, 1.0f, 0.0f); // Желтый
        GL11.glVertex2f(startX + a, startY);  // Вершина левого треугольника
        GL11.glVertex2f(startX + a + a, startY - a / 2);  // Центральная точка
        GL11.glVertex2f(startX + 2 * a, startY + a / 2);             // Вершина левого нижнего квадрата
        GL11.glEnd();

        // Желтый треугольник (справа)
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        GL11.glColor3f(1.0f, 1.0f, 0.0f); // Желтый
        GL11.glVertex2f(startX + 2 * a, startY + a / 2); // Центральная точка
        GL11.glVertex2f(startX + a, startY + a);        // Верхний угол квадрата
        GL11.glVertex2f(startX + a, startY);            // Нижний угол квадрата
        GL11.glEnd();

        // Синий квадрат (внизу, GL_POLYGON)
        GL11.glBegin(GL11.GL_POLYGON);
        GL11.glColor3f(0.0f, 0.0f, 1.0f); // Синий
        GL11.glVertex2f(startX, startY - a);        // Левый нижний
        GL11.glVertex2f(startX + a, startY - a);    // Правый нижний
        GL11.glVertex2f(startX + a, startY);        // Правый верхний
        GL11.glVertex2f(startX, startY);            // Левый верхний
        GL11.glEnd();


        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        GL11.glColor3f(1.0f, 0.0f, 0.0f);
        GL11.glVertex2f(startX + a, startY);
        GL11.glVertex2f(startX + a + a, startY - a / 2);
        GL11.glVertex2f(startX + a, startY - a);
        GL11.glEnd();
    }
}
